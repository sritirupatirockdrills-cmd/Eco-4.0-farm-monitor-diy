# EcoFarm 4.0 USB Monitor

Android app project for an Arduino Uno connected to an Android phone using USB OTG.

## Build an installable APK with GitHub Actions

The app uses Java 17 and Kotlin JVM target 17. The app-level Gradle file configures both targets to avoid the Java/Kotlin target mismatch.

### Option A — Upload the ZIP (convenient when using a phone)

1. Create a new, empty GitHub repository.
2. Upload `EcoFarm4_USB_Monitor_Project.zip` to the repository root. Keep that exact filename.
3. In the repository, choose **Add file → Create new file**.
4. Name the file `.github/workflows/build-apk.yml`.
5. Paste the contents of the companion `build-apk-from-zip.yml` workflow supplied with this project and commit the file to the `main` branch.
6. Open **Actions → Build EcoFarm 4.0 APK from ZIP** and select **Run workflow** if it has not started automatically.
7. Open the completed run, scroll to **Artifacts**, and download `EcoFarm4-USB-Monitor-APK`.
8. Extract the downloaded artifact ZIP. The installable file is `app-debug.apk`.

### Option B — Upload the extracted project

Upload the *contents* of this project folder to the root of a GitHub repository (so `app/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/` are at repository root). The included `.github/workflows/build-apk.yml` workflow will build the APK on a push to `main` or when manually started from **Actions**.

## Install on Android

Transfer `app-debug.apk` to your phone, open it, and follow Android's install prompts. If Android blocks the installation, allow **Install unknown apps** for the app you used to open the APK, then retry. Only install APKs you built or trust.

This is a debug APK for personal testing. A Play Store release or sharing broadly should use a signed release build.

## Arduino serial format

Set the Arduino sketch to `Serial.begin(9600)` and send one line per update, for example:

`TEMP:28,HUM:65,SOIL:42,TANK:85,PUMP:ON`

The app recognises these keys (case-insensitive):
- `TEMP` / `TEMPERATURE`
- `HUM` / `HUMIDITY`
- `SOIL` / `MOISTURE` / `SOIL_MOISTURE`
- `TANK` / `WATER` / `WATER_TANK`
- `PUMP` / `IRRIGATION` / `STATUS`

Use a newline at the end of each record (`Serial.println(...)`). The app uses 9600 baud, 8 data bits, no parity, 1 stop bit.

## Hardware notes

- Use a USB OTG adapter that supports USB host mode and a data-capable USB cable.
- Do not power the pump or other high-current loads from the phone's USB supply.
- The app displays values reported by the Arduino; the Arduino sketch must calculate and transmit tank percentage and other readings.
- USB serial support depends on the USB-to-serial chipset and Android device compatibility.
